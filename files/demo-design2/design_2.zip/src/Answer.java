
public abstract class Answer implements java.io.Serializable{

}
