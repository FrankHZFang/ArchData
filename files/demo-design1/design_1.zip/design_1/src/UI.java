
public abstract class UI{
	public abstract void display(String output);
	public abstract String captureString();
	public abstract int captureInt();
	public abstract int captureLetter(int max);
}
